namespace SimuladorDePatos;

public interface IQuackble{
    public void Quack();
}