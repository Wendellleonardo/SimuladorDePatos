namespace SimuladorDePatos;

public interface IFlyable
{
    public void Fly();
}