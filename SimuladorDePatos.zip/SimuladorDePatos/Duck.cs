﻿namespace SimuladorDePatos;

public class Duck{
    public virtual void display(){
        Console.WriteLine("Duck");
    }
    public void swim(){
        Console.WriteLine("Swim");
    }
    
    }
    
    